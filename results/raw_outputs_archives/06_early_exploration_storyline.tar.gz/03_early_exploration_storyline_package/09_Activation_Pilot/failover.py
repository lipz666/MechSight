"""Two-endpoint failover client (vps proxy + AI Studio gateway), same Gemini model on both.

Each model instance starts on a pseudo-random endpoint so the load splits across
both, and every failed attempt switches to the other endpoint. Keys come only
from the environment: OPENAI_API_KEY for the vps proxy, FALLBACK_API_KEY for the
gateway. Every logged event records the endpoint that answered.
"""
from __future__ import annotations

import os
import random
import time
import zlib
from pathlib import Path

import common as C

ENDPOINTS = [
    {'base_url': 'https://LLM-GATEWAY-2.example/v1', 'model': 'gemini-3.8-flash-high', 'key_env': 'OPENAI_API_KEY'},
    {'base_url': 'http://LLM-GATEWAY-1.example:8080/v1', 'model': 'gemini-3.8-flash', 'key_env': 'FALLBACK_API_KEY'},
]
MAX_ATTEMPTS = 14


class FailoverModel(C.Model):
    def __init__(self, trace, max_tokens=65536, temperature=0.2, timeout=900):
        from openai import OpenAI
        self.trace, self.max_tokens, self.temperature = Path(trace), max_tokens, temperature
        self.model = 'gemini-3.8-flash(-high)'
        self.endpoints = [dict(e, client=OpenAI(api_key=os.environ[e['key_env']], base_url=e['base_url'],
                                                timeout=timeout, max_retries=0))
                          for e in ENDPOINTS if os.environ.get(e['key_env'])]
        self.start = zlib.crc32(str(trace).encode()) % len(self.endpoints)
        self.events = []

    def _redact(self, text):
        for e in self.endpoints:
            text = text.replace(os.environ[e['key_env']], '[REDACTED]')
        return text

    def complete(self, messages, phase):
        start = time.monotonic()
        for attempt in range(MAX_ATTEMPTS):
            ep = self.endpoints[(self.start + attempt) % len(self.endpoints)]
            try:
                stream = ep['client'].chat.completions.create(
                    model=ep['model'], messages=messages, max_tokens=self.max_tokens, temperature=self.temperature,
                    reasoning_effort='high', stream=True, stream_options={'include_usage': True})
                parts, usage, returned = [], None, None
                for chunk in stream:
                    returned = chunk.model
                    if chunk.usage:
                        usage = chunk.usage.model_dump()
                    if chunk.choices and chunk.choices[0].delta.content:
                        parts.append(chunk.choices[0].delta.content)
                answer = ''.join(parts)
                if not answer.strip():
                    raise RuntimeError('empty answer')
                break
            except Exception as exc:
                self._save({'phase': phase, 'api_error': type(exc).__name__, 'status': getattr(exc, 'status_code', None),
                            'endpoint': ep['base_url'], 'retry': attempt, 'detail': self._redact(str(exc))[:300],
                            'elapsed_seconds': round(time.monotonic() - start, 1)})
                if attempt == MAX_ATTEMPTS - 1:
                    raise
                # switching endpoints is the main remedy; back off only after both have failed in a row
                if attempt % len(self.endpoints) == len(self.endpoints) - 1:
                    time.sleep(min(60, 3 * 2 ** (attempt // len(self.endpoints))) + random.random() * 3)
        event = {'phase': phase, 'model': ep['model'], 'endpoint': ep['base_url'], 'returned_model': returned,
                 'usage': usage, 'generation_tokens': C.generation_tokens(usage),
                 'elapsed_seconds': round(time.monotonic() - start, 1), 'answer': answer}
        self.events.append(event)
        self._save(event)
        return answer

    @property
    def endpoints_used(self):
        return sorted({e['endpoint'] for e in self.events})
