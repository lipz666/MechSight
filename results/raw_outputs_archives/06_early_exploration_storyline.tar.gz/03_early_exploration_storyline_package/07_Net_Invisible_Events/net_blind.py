"""Test: are LLM errors concentrated on net-invisible (transient) σ events?"""
import json, sys, glob, os
from collections import Counter, defaultdict
PKG = os.environ.get('MECHSIGHT_STORYLINE_PKG', os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, PKG)
from core_deps import fukuyama_metrics as M
from core_deps import standalone_chemistry as chem
ROOT = os.environ.get('MECHSIGHT_ROOT', 'code/MechAgent')
cases = {}
for src in [ROOT + '/outputs/fukuyama/clean.jsonl', ROOT + '/outputs/heldout_fukuyama_20261024/heldout.jsonl']:
    for line in open(src):
        c = json.loads(line); cases.setdefault(c['case_id'], c)

def pairs(steps):
    out = []
    for s in steps:
        for kind, a, b in M.sigma_events(s).elements():
            out.append((kind, a, b))
    return out

def analyze(run_dir, label):
    agg = Counter(); rows = []
    for f in sorted(glob.glob(run_dir + '/*.json')):
        r = json.load(open(f)); cid = r['case_id']
        if cid not in cases: continue
        case = cases[cid]
        try:
            init = chem.parse_pgl_literal(case['initial_state_pgl'])
            states, _ = M.replay(case['initial_state_pgl'], r.get('actions_pgl', []))
        except Exception:
            continue
        pred = [M.step_from_states(b, a) for b, a in zip([init] + states[:-1], states)]
        gold = M.gold_steps_from_clean(case)
        g_ev = [M.sigma_events(s) for s in gold]; p_ev = [M.sigma_events(s) for s in pred]
        gt_tr = M._transient(g_ev); p_tr = M._transient(p_ev)
        gflat = sum(g_ev, Counter()); pflat = sum(p_ev, Counter())
        # net events = GT events on non-transient pairs
        net = Counter({k: v for k, v in gflat.items() if (k[1], k[2]) not in gt_tr})
        net_hit = sum((net & pflat).values()); net_n = sum(net.values())
        tr_hit = len(gt_tr & p_tr); tr_n = len(gt_tr)
        spurious_tr = len(p_tr - gt_tr)
        omitted = sum((gflat - pflat).values()); extra = sum((pflat - gflat).values())
        l1 = gflat == pflat
        agg.update(net_hit=net_hit, net_n=net_n, tr_hit=tr_hit, tr_n=tr_n, spur=spurious_tr, omitted=omitted, extra=extra, n=1, l1=l1)
        rows.append(dict(cid=cid, l1=l1, ntr=tr_n, nsteps=len(gold), nnet=net_n))
    print(f'== {label}: n={agg["n"]}  σ-L1={agg["l1"]/agg["n"]:.3f}')
    print(f'  net-event recall {agg["net_hit"]}/{agg["net_n"]} = {agg["net_hit"]/agg["net_n"]:.3f}')
    print(f'  transient-pair recall {agg["tr_hit"]}/{agg["tr_n"]} = {agg["tr_hit"]/max(1,agg["tr_n"]):.3f}; spurious transient pairs {agg["spur"]}')
    print(f'  omitted events {agg["omitted"]}  extra events {agg["extra"]}')
    # stratify: σ-L1 by #transient within step-count bins
    tab = defaultdict(lambda: [0, 0])
    for r in rows:
        sb = 'steps<=3' if r['nsteps'] <= 3 else ('steps4-6' if r['nsteps'] <= 6 else 'steps>=7')
        tb = '0' if r['ntr'] == 0 else ('1-2' if r['ntr'] <= 2 else '>=3')
        tab[(sb, tb)][0] += r['l1']; tab[(sb, tb)][1] += 1
    for sb in ['steps<=3', 'steps4-6', 'steps>=7']:
        print('  ', sb, '  '.join(f'tr{tb}: {tab[(sb,tb)][0]}/{tab[(sb,tb)][1]}' for tb in ['0', '1-2', '>=3']))
    tb_only = defaultdict(lambda: [0, 0])
    for r in rows:
        tb = '0' if r['ntr'] == 0 else ('1-2' if r['ntr'] <= 2 else '>=3'); tb_only[tb][0] += r['l1']; tb_only[tb][1] += 1
    print('   by transient only:', {k: f'{v[0]}/{v[1]}={v[0]/v[1]:.2f}' for k, v in sorted(tb_only.items())})
    return rows

O = ROOT + '/outputs'
analyze(O + '/heldout_fukuyama_20261024/confirmatory/direct', 'heldout direct (flash-high, 218)')
analyze(O + '/agent_v2_J3/gemini-3.8-flash-build/direct@1', 'J3 flash-build direct (147)')
analyze(O + '/agent_v2_J3/gemini-4-argon-build/direct@1', 'J3 argon-build direct (147)')
