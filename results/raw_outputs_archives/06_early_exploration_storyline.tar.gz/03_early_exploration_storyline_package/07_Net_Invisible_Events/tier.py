import json, os, sys, glob
from collections import defaultdict
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import net_blind as N
# reuse: rows with partition
import contextlib, io
with contextlib.redirect_stdout(io.StringIO()):
    rows = N.analyze(N.O + '/heldout_fukuyama_20261024/confirmatory/direct', 'x')
def heavy(pair): return not (pair[0].startswith('H') or pair[1].startswith('H'))
tab = defaultdict(list)
for r in rows:
    c = N.cases[r['cid']]; g = [N.M.sigma_events(s) for s in N.M.gold_steps_from_clean(c)]
    tr = N.M._transient(g); htr = [p for p in tr if heavy(p)]
    tab[c['partition']].append((r['ntr'], len(htr), r['nsteps'], r['l1']))
for t in sorted(tab):
    v = tab[t]; n = len(v)
    print(t, 'n', n, 'mean transient', round(sum(x[0] for x in v)/n, 2), 'heavy-only', round(sum(x[1] for x in v)/n, 2),
          'mean steps', round(sum(x[2] for x in v)/n, 1), 'σ-L1', round(sum(x[3] for x in v)/n, 2))
print('σ-L1 by tier within transient strata:')
for tb, f in [('0', lambda k: k == 0), ('1-2', lambda k: 1 <= k <= 2), ('>=3', lambda k: k >= 3)]:
    print(' tr', tb, {t: f"{sum(x[3] for x in tab[t] if f(x[0]))}/{sum(1 for x in tab[t] if f(x[0]))}" for t in sorted(tab)})
print('share of transient that are heavy-atom:', sum(x[1] for t in tab for x in tab[t]), '/', sum(x[0] for t in tab for x in tab[t]))
