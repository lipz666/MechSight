"""Fraction of FlowER (template-imputed) sequences containing heavy-atom transient bonds."""
import sys, random
from collections import defaultdict, OrderedDict
from rdkit import Chem
from rdkit import RDLogger; RDLogger.DisableLog('rdApp.*')
path = sys.argv[1]
seqs = OrderedDict()
for line in open(path):
    rxn, idx = line.strip().rsplit('|', 1)
    seqs.setdefault(idx, []).append(rxn)
keys = list(seqs); random.seed(0); keys = random.sample(keys, min(3000, len(keys)))
def bonds(smi):
    m = Chem.MolFromSmiles(smi, sanitize=False)
    out = set()
    for b in m.GetBonds():
        a, c = b.GetBeginAtom(), b.GetEndAtom()
        if a.GetSymbol() == 'H' or c.GetSymbol() == 'H': continue
        out.add(tuple(sorted((a.GetAtomMapNum(), c.GetAtomMapNum()))))
    return out
n = with_tr = tot_tr = steps = bad = 0
for k in keys:
    try:
        kinds = defaultdict(set)
        for rxn in seqs[k]:
            r, p = rxn.split('>>'); br, bp = bonds(r), bonds(p)
            for x in bp - br: kinds[x].add('form')
            for x in br - bp: kinds[x].add('break')
        tr = [x for x, s in kinds.items() if s == {'form', 'break'}]
    except Exception:
        bad += 1; continue
    n += 1; steps += len(seqs[k]); tot_tr += len(tr); with_tr += bool(tr)
print(f'{path}: sequences {n} (bad {bad}), mean steps {steps/n:.1f}, '
      f'with ≥1 heavy-atom transient {with_tr/n:.1%}, mean heavy transient {tot_tr/n:.2f}')
