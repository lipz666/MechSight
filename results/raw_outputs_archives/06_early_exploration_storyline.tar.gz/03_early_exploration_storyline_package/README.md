# MechAgent 核心实验包 (故事线与实验全集)

本实验包完整收录并整理了用户图片（故事线：机理预测是知识驱动任务）所对应的**全部实验代码、复现脚本、评测数据、关键输出与论文高清图表**。

---

## 📸 图片核心结论与实验对照索引

| 图片故事线模块 | 核心实验结论与关键数字 | 对应目录与核心产物 | 对应复现图表 |
|---|---|---|---|
| **1. [问题] 现有 AI 机理训练评测退化为模板** | 在 MechFinder 上，**不用 LLM 的模板检索能达到 81.3%**（L1），高于 LLM Direct (44.4%) 和 Agent (48.8%) 约 +32.5pp；而在 FlowER 自身测试集上，朴素模板检索完整路径精确匹配为 55.9%。 | [`01_Problem_Template_Degeneration/`](./01_Problem_Template_Degeneration/)<br>• `summary.json`<br>• `run.py` | 图1 `fig1_template_degeneration.png` |
| **2. [核心正结论] 模板外真实机理上知识驱动通用 LLM 全面领先专用模型 FlowER** | 在 FukuyamaBench 开发集 24 题上：<br>• **σ-L1 成键/断键事件正确率**：FlowER **0%**，LLM Agent（正向不给目标）**33%**，LLM Direct（给定目标）**51%**<br>• **GT 中间态按序命中率**：FlowER **0%**，LLM Agent **25%**，LLM Direct **32%**<br>• **FlowER 失败方式 (45题)**：任一路径到产物 **0题**（11题第一步报不反应，8题20min超时，26题无路径到产物） | [`02_LLM_vs_FlowER_FukuyamaBench/`](./02_LLM_vs_FlowER_FukuyamaBench/)<br>• `COMPARE_1a.json`<br>• `dev_24_cases/`<br>• `heldout_21_cases/` | **图2 `fig2_llm_vs_flower.png` (与图片完全一致)** |
| **3. [方法学] 提出并验证新指标 (σ-L1 + GT 中间态按序命中)** | 解决传统指标对共振式和分步粒度敏感的问题。GT 自洽 60/60，通过 9 项单元测试。**旧指标大约把历史成绩低估了一半**（历史 Agent 旧口径 20% → 新指标 σ-L1 52% / 按序命中 36%；Set C 从 0% 变为 25%）。 | [`03_Methodology_Metrics_Rescore/`](./03_Methodology_Metrics_Rescore/)<br>• `fukuyama_metrics.py`<br>• `test_fukuyama_metrics.py`<br>• `summary.json` | 图3 `fig3_metric_fix.png` |
| **4. [诊断] 瓶颈在隐藏事件** | • **LLM 偏好最短路径**：漏写 50 个 σ 事件，多写的只有 2 个<br>• **知道隐藏事件大幅提升**：告知 GT 瞬态键，σ-L1 提升 29~45pp<br>• **认出比想出容易**：混入 50% 干扰候选（oracle_noisy）仍能维持 +45pp 增益，而只给一半正确键（oracle_half 召回 50%）则无增益 | [`04_Diagnosis_Hidden_Events/`](./04_Diagnosis_Hidden_Events/)<br>• `compare_summary.json`<br>• `compare_rows.json`<br>• `run.py` | 图4 `fig4_hidden_event_bottleneck.png` |
| **5. [严格的负结果] 纯 LLM 9 大失败模式** | 详细支撑数据与实验设计：<br>1. **漏写隐藏事件**：偏好最短路径，漏写 50 个，多写 2 个 (F1)<br>2. **采样坍缩**：5 次采样中位数仅 1 种答案 (F2)<br>3. **自我纠错无效**：检查修改答案修好 0 条改坏 0 条 (F3)<br>4. **给了知识用不上**：条件、类比、规划增益不到 1pp (F4)<br>5. **顺序判断差**：告诉瞬态键后 σ-L1 79% 但按序命中仅 33% (F5)<br>6. **依赖目标产物**：不给目标 33%，给了 51% (F7)<br>7. **定量知识粗**：估计 Mayr/pKa 选步骤比直接挑低 50-61pp (F8)<br>8. **分不清自己的候选**：规则负例挑对 93%，模型候选仅 78% (F9)<br>9. **误差累积**：单步 73%，五步连乘约 21% 吻合 RMR 22% (F10) | [`05_Strict_Negative_Results/`](./05_Strict_Negative_Results/)<br>• 包含 F1-F10 独立子目录、数据与分析脚本 | 图4(a) 及各子目录 JSON 证据 |
| **6. [方法与留出集探索] MechAgent 架构探索** | 探索了候选短名单（shortlist）、两两比较裁决锦标赛（J1-J4）、逐步搜索（step_search）等方案，均进行了严格的预先登记或门槛测试。 | [`06_Method_Explorations/`](./06_Method_Explorations/)<br>• `heldout_confirmatory/`<br>• `agent_v2/`<br>• `step_search/` | 详见各方法探索目录 |

---

## 🗂️ 目录组织结构

```text
MechAgent_Storyline_Experiments_Package/
├── README.md                           # 本总览文件
├── MANIFEST.json                       # 文件与元数据索引清单
├── 00_Overview_and_Storyline/          # 故事线、总结文档与全部高清图表
│   ├── paper_storyline_20261026.md     # 完整五段故事线与论证
│   ├── progress_20261101.md            # 最新实验进展与负结果汇总
│   ├── pilot_experiments_20261024.md   # 预实验详尽报告 (P1-P5)
│   ├── direction2_ideas_20261031.md    # 方法探索与分析
│   ├── reproduce_figures.py            # 一键复现图1-4的独立脚本
│   └── figures/                        # 高清矢量图与位图 (含图2原图)
├── 01_Problem_Template_Degeneration/   # ① 问题：MechFinder 模板退化实验
│   ├── scripts/                        # run.py, fukuyama_coverage.py
│   ├── outputs/                        # summary.json, rows.jsonl 等
│   └── baseline_comparison/            # 对照数据 (Direct 44.4%, FlowER 55.9%)
├── 02_LLM_vs_FlowER_FukuyamaBench/      # ② 核心正结论：LLM vs FlowER 对比评测 (对应图2)
│   ├── scripts/                        # compare.py, flower_driver.py 等
│   └── outputs/                        # COMPARE_1a.json, dev_24_cases, heldout_21_cases
├── 03_Methodology_Metrics_Rescore/      # ③ 方法学：σ-L1 与按序命中新指标重算 (对应图3)
│   ├── develop/                        # fukuyama_metrics.py, 单元测试
│   ├── scripts/                        # rescore.py
│   └── outputs/                        # summary.json, REPORT.md, rows.jsonl
├── 04_Diagnosis_Hidden_Events/         # ④ 诊断：隐藏事件瓶颈探针 (对应图4)
│   ├── scripts/                        # run.py, compare.py, analogs.py, passk.py
│   └── outputs/                        # compare_summary.json, 各 arm 实验数据
├── 05_Strict_Negative_Results/         # ⑤ 纯 LLM 9 大严格负结果支撑数据 (F1-F10)
│   ├── F1_Shortest_Path/               # 漏写 50 个 σ 事件，多写 2 个
│   ├── F2_Sampling_Collapse/           # 采样坍缩 (5次采样中位数仅1种有效答案)
│   ├── F3_Self_Correction/             # 自我纠错无效 (修好 0 条，改坏 0 条)
│   ├── F4_Knowledge_Useless/           # 给了知识也用不上 (增益 < 1pp)
│   ├── F5_Order_Disruption/            # 顺序判断差 (瞬态已知但按序命中仅 33%)
│   ├── F7_Target_Dependence/           # 依赖目标产物 (不给 33%，给 51%)
│   ├── F8_Quantitative_Scales/         # 定量知识粗 (Mayr/pKa 比直接挑低 50-61pp)
│   ├── F9_Model_Own_Candidates/        # 分不清自己的候选 (规则 93% vs 自选 78%)
│   └── F10_Error_Accumulation/         # 误差累积 (单步 73%, 连乘 21% 吻合 RMR 22%)
├── 06_Method_Explorations/             # ⑥ 方法探索与留出集验证
│   ├── heldout_confirmatory/           # 留出集 123 题预先登记确认实验
│   ├── agent_v2/                       # 模式库 + 两两对比裁决 J1-J4
│   └── step_search/                    # 逐步搜索预实验
└── core_deps/                          # 核心依赖库与基准数据
    ├── fukuyama_metrics.py             # 指标核心计算模块
    ├── standalone_chemistry.py         # 化学解析库
    ├── metrics.py                      # Bootstrap CI 统计模块
    └── fukuyama_clean.jsonl            # 福山基准题目数据 (60题标准格式)
```

---

## ⚡ 快速复现与验证指南

### 1. 一键复现全部图表 (包含图2原图)
本实验包包含自包含的绘图脚本 `reproduce_figures.py`，无需网络，直接读取包内 JSON 结果生成高清图表：
```bash
# 激活具备 matplotlib 与 rdkit 的 Python 环境
python 00_Overview_and_Storyline/reproduce_figures.py
```
运行后，图表将输出到 `00_Overview_and_Storyline/figures/`：
- `fig1_template_degeneration.png`：MechFinder 上模板检索 81.3% 远超 LLM
- `fig2_llm_vs_flower.png`：**【图片图2原图】** FukuyamaBench 24 题 FlowER 0% vs LLM 33-51%
- `fig3_metric_fix.png`：新旧指标对比，旧指标低估一半
- `fig4_hidden_event_bottleneck.png`：隐藏事件瓶颈 (漏写 50 vs 多写 2；noisy 50% vs half 50%)

### 2. 查看各项实验的具体数据
所有指标直接存储在格式规范的 JSON/JSONL 文件中，可直接用 `jq` 或 Python 查看：
```bash
# 1. 查看 FlowER vs LLM 核心对比 (图2)
cat 02_LLM_vs_FlowER_FukuyamaBench/outputs/COMPARE_1a.json

# 2. 查看隐藏事件探针各组对比 (图4)
cat 04_Diagnosis_Hidden_Events/outputs/compare_summary.json

# 3. 查看定量知识粗糙负结果 (F8: -50pp / -61.1pp)
cat 05_Strict_Negative_Results/F8_Quantitative_Scales/SUMMARY.json

# 4. 查看分不清自己的候选负结果 (F9: 93% vs 78%)
cat 05_Strict_Negative_Results/F9_Model_Own_Candidates/SELECT_OWN.json
cat 05_Strict_Negative_Results/F9_Model_Own_Candidates/hard_rule_distractors_summary.json
```
