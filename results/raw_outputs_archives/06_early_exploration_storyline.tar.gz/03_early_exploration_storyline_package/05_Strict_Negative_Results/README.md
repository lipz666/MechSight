# 纯 LLM 的 9 大严格负结果支撑实验 (F1 - F10)

本目录完整汇集了故事线第 5 部分所列出的纯 LLM 失败模式的**全部实验脚本、原始输出数据与统计结果**。每一条结论均有确凿的实验数据支持。

---

## 📋 负结果全景索引

| 编号 | 失败模式 | 核心数字与证据 | 存放目录与核心文件 |
|---|---|---|---|
| **F1** | **漏写隐藏事件** | 偏好最短路径。开发集 24 题中，**漏写的 σ 事件 50 个，多写的只有 2 个**。按瞬态键数分层，σ-L1 依次为 89% → 36% → 17%。 | [`F1_Shortest_Path/`](./F1_Shortest_Path/)<br>• `compare_rows.json`<br>• `figure4a_script.py` |
| **F2** | **采样坍缩** | 5 次独立采样，**中位数只有 1 种有效答案**（`distinct_valid_states_median: 1`）；4 次独立采样平均只有 1.17 种答案，`pass@4` 54% ≈ `pass@1` 51%，多采样几乎没有增益。 | [`F2_Sampling_Collapse/`](./F2_Sampling_Collapse/)<br>• `passk_summary.json`<br>• `recall_summary.json` |
| **F3** | **自我纠错无效** | 让模型检查并修改自己的答案，**修好 0 条，改坏 0 条**。Review 审核批准率 100%，错误检出率 0%。在 Fukuyama 上 180 对改动 27 条，修好 0 改坏 0。 | [`F3_Self_Correction/`](./F3_Self_Correction/)<br>• `p45_trace_analysis.json`<br>• `analyze.py` |
| **F4** | **给了知识也用不上** | 反应条件 (+1.0pp)、类比机理 (+1.0pp)、规划提示，**增益都不到 1pp**；在固定预算下注入 Skill 反而因消耗 token 导致早停有害。 | [`F4_Knowledge_Useless/`](./F4_Knowledge_Useless/)<br>• `compare_summary.json`<br>• `analogs.py` |
| **F5** | **顺序判断差** | 告诉它瞬态键后 σ-L1 提升到 79.2%，但**按序命中仍只有 33.3%**。事件虽然补全，但步序排列错乱，且容易把分步误判为协同。 | [`F5_Order_Disruption/`](./F5_Order_Disruption/)<br>• `compare_summary.json` (oracle_lat 组) |
| **F7** | **依赖目标产物** | 不给目标产物时 σ-L1 为 **33.3%**，给了目标产物为 **51.0%**（开发集 24 题）。 | [`F7_Target_Dependence/`](./F7_Target_Dependence/)<br>• `summary.json` (agent_forward vs direct) |
| **F8** | **定量知识粗** | 先让它估计 Mayr/pKa 参数再用物理公式挑选机理步骤，**比直接挑低 50~61pp**（argon-build: -50.0pp; flash-build: -61.1pp）。LLM 的定量参数估计严重不可靠。 | [`F8_Quantitative_Scales/`](./F8_Quantitative_Scales/)<br>• `SUMMARY.json`<br>• `probe.py` |
| **F9** | **分不清自己的候选** | 错误选项由规则生成时（严格控制步长与目标距离）能挑对 **92.7% (~93%)**；换成模型自己提的替代候选时只有 **78.0%**。"先列候选再自己挑"比直接采样一次还低 5.2pp。 | [`F9_Model_Own_Candidates/`](./F9_Model_Own_Candidates/)<br>• `SELECT_OWN.json`<br>• `hard_rule_distractors_summary.json` |
| **F10** | **误差累积** | 在正确前缀下，**单步准确率 73.0%**；五步连乘 $0.73^5 pprox 20.7\% (~21\%)$，与 RMR 论文中 Gemini-3-Pro 在 A 级上的 **22%** 精确匹配高度吻合。 | [`F10_Error_Accumulation/`](./F10_Error_Accumulation/)<br>• `SUMMARY.json`<br>• `gap_audit/` (43个偏差案例人工与Claude审计) |
